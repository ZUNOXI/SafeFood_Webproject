package edu.ssafy.food.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import edu.ssafy.food.dto.ComVO;
import edu.ssafy.food.dto.QnaVO;
import edu.ssafy.food.service.ComService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api")
@Api(value = "SSAFY", description = "SSAFY Resouces Management 2019")
public class ComController {
	
	public static final Logger logger = LoggerFactory.getLogger(QnaController.class);
	
	@Autowired
	@Qualifier("ComServiceImpl")
	private ComService ser;
	
	@ApiOperation(value = "댓글을 추가한다.", response = ComVO.class)
	@RequestMapping(value = "/addComment", method = RequestMethod.POST)
	public ResponseEntity<ComVO> addComment(@RequestBody ComVO dto) throws Exception {
		logger.info("1-------------addComment-----------------------------" + new Date());
		System.out.println("코멘트 추가!");
		System.out.println(dto.getNumc()+" "+dto.getContent()+" "+dto.getLink()+" "+dto.getId()+" "+dto.getPw());
		boolean total = ser.insert(dto.getNumc(), dto.getContent(), dto.getLink(), dto.getId(),dto.getPw());
		if(dto.getNumc()==0) {
			total = true;
		}
		ComVO nr = new ComVO();
//   		nr.setCount(total);
//   		nr.setName("addEmployee");
//   		nr.setState("succ");
		logger.info("5-------------addComment-------id------------------" + total);
		if (total == true) {
//   			nr.setCount(-1);
//   	   		nr.setName("addEmployee");
//   	   		nr.setState("fail");
			// return new ResponseEntity(HttpStatus.NO_CONTENT);
			return new ResponseEntity<ComVO>(nr, HttpStatus.OK);
		}
		return new ResponseEntity<ComVO>(nr, HttpStatus.OK);
	}
	
	@ApiOperation(value ="댓글들을 보여준다", response = List.class)
	@RequestMapping(value = "/findAllComment/{num}", method = RequestMethod.GET)
	public ResponseEntity<List<ComVO>>findAllComment(@PathVariable int num) throws Exception{
		System.out.println("댓글을 원해");
		List<ComVO>list = new ArrayList<ComVO>();
		
		if(ser.selectlist(num)!=null) {
			System.out.println("null이 아니다");
			list = ser.selectlist(num);
			return new ResponseEntity<List<ComVO>>(list, HttpStatus.OK);	
		}
		System.out.println("null이다");
		return new ResponseEntity(HttpStatus.NO_CONTENT);
		
	}
	
	@ApiOperation(value = " 해당사원의 정보를 삭제한다. 사원의 정보를 삭제하기전, 정산하고 , 잡히스토리 수정등 여러 작업을 해야한다. 여기서는 히스토리를 모두 지우고(수정한 적이 없다면 바로 삭제가능) 삭제할 수 있다 . 원래 delete다", response = ComVO.class)
	@RequestMapping(value = "/deletecom/{pw}/{num}", method = RequestMethod.POST)
	public ResponseEntity<String> deletecom(@PathVariable String pw, @PathVariable int num) throws Exception {
		logger.info("1-------------deletecom-----------------------------" + new Date());
		logger.info("1-------------deletecom-----------------------------" + num);
		
		System.out.println(pw);
		System.out.println(num);
		ComVO com =ser.selectone(num);
		System.out.println(com.getPw());
		boolean total = false;
		if(com.getPw().equals(pw)) {
			total = ser.delete(num);
		}			
		if (!total) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<String>("succ", HttpStatus.OK);
	}
}
