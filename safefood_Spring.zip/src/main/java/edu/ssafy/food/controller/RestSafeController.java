package edu.ssafy.food.controller;

import java.sql.SQLException;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.ssafy.food.dto.FoodVO;
import edu.ssafy.food.dto.MemVO;
import edu.ssafy.food.service.FoodService;
import edu.ssafy.food.service.MemService;

//@RestController
//@RequestMapping("/asdad")
public class RestSafeController {

	@Autowired
	@Qualifier("MemServiceImpl")
	MemService ser;

	@Autowired
	@Qualifier("FoodServiceImpl")
	FoodService foodser;
	
	
	@Autowired
	private ServletContext servletContext;
	
	@PostMapping("/signUp")
	public ResponseEntity insert(MemVO mem) {
		ResponseEntity re = null;
		try {
			ser.addMem(mem.getId(), mem.getPw(), mem.getName(),mem.getAddr(), mem.getEmail(),mem.getTel(),mem.getAlinfo());
			re = new ResponseEntity("잘들어갔어요", HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity("입력실패했어요", HttpStatus.NOT_MODIFIED);
		}
		return re;
	}

	@PutMapping("/memupdate")
	public ResponseEntity<String> update(MemVO mem) {
		ResponseEntity re = null;
		try {
			ser.updateMem(mem.getId(), mem.getPw(), mem.getName(),mem.getAddr(), mem.getEmail(),mem.getTel(),mem.getAlinfo());
			re = new ResponseEntity<String>("잘수정되었어요", HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity<String>("수정실패했어요", HttpStatus.NOT_MODIFIED);
		}
		return re;
	}

	@DeleteMapping("/memdelete/{id}")
	public ResponseEntity delete(@PathVariable String id) {
		ResponseEntity re = null;
		try {
			ser.delMem(id);
			re = new ResponseEntity<String>("잘삭제되었어요", HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity<String>("삭제실패했어요", HttpStatus.NOT_MODIFIED);
		}
		return re;
	}

	@GetMapping("/memselone/{id}")
	public ResponseEntity<MemVO> selectOne(@PathVariable String id) {
		ResponseEntity<MemVO> re = null;
		try {
			MemVO selectOne = ser.selectOne(id);
			re = new ResponseEntity<MemVO>(selectOne, HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity("조회실패했어요", HttpStatus.NO_CONTENT);
		}
		return re;
	}

	@GetMapping("/memsellist")
	public ResponseEntity<List<MemVO>> selectList() {
		System.out.println("");
		ResponseEntity<List<MemVO>> re = null;
		try {
			List<MemVO> list = ser.selectList();
			re = new ResponseEntity<List<MemVO>>(list, HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity("조회실패했어요", HttpStatus.NO_CONTENT);
		}
		return re;
	}
	
	@GetMapping("/login/{id}/{pw}")
	public ResponseEntity<MemVO> login(@PathVariable String id,@PathVariable String pw) {
		ResponseEntity<MemVO> re = null;
		try {
			MemVO log = ser.login(id, pw);
			re = new ResponseEntity<MemVO>(log, HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity("로그인실패했어요", HttpStatus.NO_CONTENT);
		}
		return re;
	}
	
	@GetMapping("/main")
	public String Main() {
		String url = servletContext.getRealPath("/WEB-INF/res/foodInfo.xml");
		String url2 = servletContext.getRealPath("/WEB-INF/res/FoodNutritionInfo.xml");
		
		String s = "";
		try {
			foodser.loadData(url, url2);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			s="main";
		}finally {
			System.out.println("메인으로 가즈아");
			return "main";
		}
		
	}
	
	@GetMapping("/pdetail")
	public void Pdetail() {
	}
	
	@GetMapping("/productlist")
	public ResponseEntity<List<FoodVO>> productlist() {
		System.out.println("");
		ResponseEntity<List<FoodVO>> re = null;
		try {
			List<FoodVO> list = foodser.getFoodList();
			re = new ResponseEntity<List<FoodVO>>(list, HttpStatus.OK);
		} catch (Exception e) {
			re = new ResponseEntity("조회실패했어요", HttpStatus.NO_CONTENT);
		}
		return re;
	}
	
	@GetMapping("/Logout")
	public void Logout() {
	}
	
	@GetMapping("/searchProduct")
	public void searchProduct() {
	}
	
	@GetMapping("/date")
	public void date() {
	}
	
	@GetMapping("/calo")
	public void calo() {
	}
	
	@GetMapping("/searchpw")
	public void searchpw() {
	}
	
	@GetMapping("/shoppingbox")
	public void shoppingbox() {
	}
	
	
	
}
