package edu.ssafy.food.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import edu.ssafy.food.dto.CartVO;
import edu.ssafy.food.dto.FoodVO;
import edu.ssafy.food.repository.CartRepo;
import edu.ssafy.food.service.CartService;
import edu.ssafy.food.service.FoodService;

@Controller
public class CartController {

	@Autowired
	@Qualifier("CartServiceImpl")
	private CartService ser;

	@Autowired
	@Qualifier("FoodServiceImpl")
	private FoodService Foodser;

	@RequestMapping("/pickinsert")
	public ModelAndView insert(HttpSession se, HttpServletRequest request, ModelAndView mv) {

		System.out.println("Qweqweqwe");
		int code = Integer.parseInt(request.getParameter("btncode"));
		String userid = (String) request.getSession().getAttribute("id");
		boolean flag = true;
		List<CartVO> list = ser.selectAllList();
		for (int i = 0; i < list.size(); i++) {
			if (userid.equals(list.get(i).getUserid())) {
				if (code == list.get(i).getFoodid()) {
					flag = false;
					int nm = list.get(i).getAmount();
					ser.update(userid, code, nm);
				}
			}
		}
		if (flag) {
			ser.addCart(userid, code, 0);
		}
		mv.setViewName("redirect:/productInfo");
		return mv;
	}

	@RequestMapping("/selectPick")
	public ModelAndView selectList(HttpServletRequest request, ModelAndView mv) {
		String id = (String) request.getSession().getAttribute("id");
		List<FoodVO> list = new ArrayList<>();
		List<Integer> codelist = ser.selectlist(id);
		List<FoodVO> foodlist = Foodser.getFoodList();
		for (int i = 0; i < codelist.size(); i++) {
			for (int j = 0; j < foodlist.size(); j++) {
				if (foodlist.get(j).getCode() == codelist.get(i)) {
					list.add(new FoodVO(foodlist.get(j).getName(), foodlist.get(j).getMaker(),
							foodlist.get(j).getImage(), foodlist.get(j).getCode(), foodlist.get(j).getCalory()));
				}
			}
		}
		mv.addObject("food", list);
		mv.setViewName("pick");
		return mv;
	}

	@RequestMapping("/delpick")
	public ModelAndView delPick(HttpServletRequest request, ModelAndView mv) {
		String id = (String) request.getSession().getAttribute("id");
		List<CartVO> cartlist = ser.selectcartid(id);
		int code = Integer.parseInt(request.getParameter("code"));
		List<FoodVO> foodlist = Foodser.getFoodList();
		for (int i = 0; i < cartlist.size(); i++) {
			if (id.equals(cartlist.get(i).getUserid())) {
				if (cartlist.get(i).getFoodid() == code) {
					ser.delCart(cartlist.get(i).getCartid());
				}
			}
		}
		mv.addObject("food", cartlist);
		mv.setViewName("redirect:/selectPick");
		return mv;
	}

}
