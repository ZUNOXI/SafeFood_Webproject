package edu.ssafy.food.service;

import java.util.List;

import edu.ssafy.food.dto.CartVO;

public interface CartService {
	public void addCart(String userid, int foodid, int amount);
	public List<Integer> selectlist(String id);
	public List<CartVO> selectAllList();
	public void delCart(int cartid);
	public void update(String userid, int foodid, int amount);
	public List<CartVO> selectcartid(String id);
}
