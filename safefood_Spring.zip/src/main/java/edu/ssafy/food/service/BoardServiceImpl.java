package edu.ssafy.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import edu.ssafy.food.dto.BoardVO;
import edu.ssafy.food.repository.BoardRepo;

@Service("BoardServiceImpl")
public class BoardServiceImpl implements BoardService {

	@Autowired
	@Qualifier("BoardMybatisRepo")
	private BoardRepo repo;
	
	@Override
	public boolean insert(int num, String title, String content, String id) {
		return repo.insert(new BoardVO(num, title, content, id));
	}

	@Override
	public void update(int num, String title, String content, String id) {
		repo.update(new BoardVO(num, title, content, id));
	}

	@Override
	public boolean delete(int num) {
		// TODO Auto-generated method stub
		return repo.delete(num);
	}

	@Override
	public List<BoardVO> selectlist() {
		// TODO Auto-generated method stub
		return repo.selectlist();
	}

	@Override
	public BoardVO selectone(int num) {
		// TODO Auto-generated method stub
		return repo.selectone(num);
	}

}
