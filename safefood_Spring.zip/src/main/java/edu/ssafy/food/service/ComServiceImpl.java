package edu.ssafy.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import edu.ssafy.food.dto.ComVO;
import edu.ssafy.food.repository.ComRepo;

@Service("ComServiceImpl")
public class ComServiceImpl implements ComService {

	@Autowired
	@Qualifier("ComRepoImpl")
	private ComRepo repo;
	
	@Override
	public boolean insert(int numc, String content, int link, String id,String pw) {
		// TODO Auto-generated method stub
		return repo.insert(new ComVO(numc, content, id, pw, link));
	}

	@Override
	public void update(int numc, String content, int link, String id,String pw) {
		repo.update(new ComVO(numc, content, id, pw, link));
	}

	@Override
	public boolean delete(int numc) {
		// TODO Auto-generated method stub
		return repo.delete(numc);
	}

	@Override
	public List<ComVO> selectlist(int num) {
		// TODO Auto-generated method stub
		return repo.selectlist(num);
	}

	@Override
	public ComVO selectone(int numc) {
		// TODO Auto-generated method stub
		return repo.selectone(numc);
	}

}
