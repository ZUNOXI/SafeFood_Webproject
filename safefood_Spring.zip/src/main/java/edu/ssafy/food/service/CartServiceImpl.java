package edu.ssafy.food.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import edu.ssafy.food.dto.CartVO;
import edu.ssafy.food.repository.CartRepo;

@Service("CartServiceImpl")
public class CartServiceImpl implements CartService {

	@Autowired
	@Qualifier("CartRepoImpl")
	private CartRepo repo;

	@Override
	public void addCart(String userid, int foodid, int amount) {
		repo.insert(new CartVO(userid, foodid, amount));

	}

	@Override
	public List<Integer> selectlist(String id) {
		// TODO Auto-generated method stub
		return repo.selectlist(id);
	}

	@Override
	public void delCart(int cartid) {
		// TODO Auto-generated method stub
		repo.delete(cartid);
	}

	@Override
	public void update(String userid, int foodid, int amount) {
		// TODO Auto-generated method stub
		repo.update(new CartVO(userid, foodid, amount));
	}

	@Override
	public List<CartVO> selectAllList() {
		// TODO Auto-generated method stub
		return repo.selectAllList();
	}

	@Override
	public List<CartVO> selectcartid(String id) {
		// TODO Auto-generated method stub
		return repo.selectcartid(id);
	}
}
