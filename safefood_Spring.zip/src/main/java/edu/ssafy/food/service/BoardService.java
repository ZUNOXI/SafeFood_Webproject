package edu.ssafy.food.service;

import java.util.List;

import edu.ssafy.food.dto.BoardVO;

public interface BoardService {
	public boolean insert(int num, String title, String content, String id);
	public void update(int num, String title, String content, String id);
	public boolean delete(int num);
	public List<BoardVO> selectlist();
	public BoardVO selectone(int num);
}
