package edu.ssafy.food.service;

import java.util.List;

import edu.ssafy.food.dto.QnaVO;

public interface QnaService {
	public boolean insert(int num, String title, String content, String id,String pw);
	public void update(int num, String title, String content, String id,String pw);
	public boolean delete(int num);
	public List<QnaVO> selectlist();
	public QnaVO selectone(int num);
	public QnaVO selectpw(String pw);
}
