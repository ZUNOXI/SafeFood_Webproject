package edu.ssafy.food.service;

import java.util.List;

import edu.ssafy.food.dto.ComVO;

public interface ComService {
		public boolean insert(int numc, String content, int link, String id,String pw);
		public void update(int numc, String content, int link, String id,String pw);
		public boolean delete(int num);
		public List<ComVO> selectlist(int num);
		public ComVO selectone(int num);
	}
