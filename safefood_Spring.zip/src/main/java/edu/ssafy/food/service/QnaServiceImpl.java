package edu.ssafy.food.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import edu.ssafy.food.dto.QnaVO;
import edu.ssafy.food.repository.QnaRepo;

@Service("QnaServiceImpl")
public class QnaServiceImpl implements QnaService {

	@Autowired
	@Qualifier("QnaRepoImpl")
	private QnaRepo repo;

	public QnaServiceImpl() {

	}

	@Override
	public boolean insert(int num, String title, String content, String id,String pw) {
		return repo.insert(new QnaVO(num, title, content, id,pw));
	}

	@Override
	public void update(int num, String title, String content, String id,String pw) {
		// TODO Auto-generated method stub
		repo.update(new QnaVO(num, title, content, id,pw));
	}

	@Override
	public boolean delete(int num) {
		// TODO Auto-generated method stub
		return repo.delete(num);
	}

	@Override
	public List<QnaVO> selectlist() {
		// TODO Auto-generated method stub
		return repo.selectlist();
	}

	@Override
	public QnaVO selectone(int num) {
		// TODO Auto-generated method stub
		return repo.selectone(num);
	}

	@Override
	public QnaVO selectpw(String pw) {
		// TODO Auto-generated method stub
		return repo.selectpw(pw);
	}

}
