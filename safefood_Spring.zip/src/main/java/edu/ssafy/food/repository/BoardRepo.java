package edu.ssafy.food.repository;

import java.util.List;

import edu.ssafy.food.dto.BoardVO;


public interface BoardRepo {
	public boolean insert(BoardVO b);
	public void update(BoardVO b);
	public boolean delete(int num);
	public List<BoardVO> selectlist();
	public BoardVO selectone(int num);
}
