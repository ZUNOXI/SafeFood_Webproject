package edu.ssafy.food.repository;

import java.util.List;

import edu.ssafy.food.dto.CartVO;

public interface CartRepo {
	public void insert(CartVO c);
	public List<Integer> selectlist(String id);
	public List<CartVO> selectAllList();
	public void delete(int cartid);
	public void update(CartVO c);
	public List<CartVO> selectcartid(String id);
}
