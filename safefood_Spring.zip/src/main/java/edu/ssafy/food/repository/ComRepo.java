package edu.ssafy.food.repository;

import java.util.List;

import edu.ssafy.food.dto.ComVO;

public interface ComRepo {
	public boolean insert(ComVO c);
	public void update(ComVO c);
	public boolean delete(int numc);
	public List<ComVO> selectlist(int num);
	public ComVO selectone(int numc);
}
