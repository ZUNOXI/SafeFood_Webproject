package edu.ssafy.food.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.ssafy.food.dto.QnaVO;

@Repository("QnaRepoImpl")
public class QnaRepoImpl implements QnaRepo {

	@Autowired
	private SqlSession session;

	@Override
	public boolean insert(QnaVO q) {
		int res = session.insert("qna.insert", q);
		if (res == 1)
			return true;
		else
			return false;
	}

	@Override
	public void update(QnaVO q) {
		session.update("qna.update", q);
	}

	@Override
	public boolean delete(int num) {
		int res = session.delete("qna.delete", num);
		if (res == 1)
			return true;
		else
			return false;
	}

	@Override
	public List<QnaVO> selectlist() {
		return session.selectList("qna.selectlist");
	}

	@Override
	public QnaVO selectone(int num) {
		return session.selectOne("qna.selectone",num);
	}

	@Override
	public QnaVO selectpw(String pw) {
		// TODO Auto-generated method stub
		return session.selectOne("qna.selectpw", pw);
	}

}
