package edu.ssafy.food.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.ssafy.food.dto.BoardVO;

@Repository("BoardMybatisRepo")
public class BoardMybatisRepo implements BoardRepo {

	@Autowired
	private SqlSession session;

	@Override
	public boolean insert(BoardVO b) {
		int res = session.insert("board.insert", b);
		if (res == 1) {
			return true;
		} else
			return false;
	}

	@Override
	public void update(BoardVO b) {
		session.update("board.update", b);
	}

	@Override
	public boolean delete(int num) {
		int res = session.delete("board.delete", num);
		if (res == 1) {
			return true;
		} else
			return false;
	}

	@Override
	public List<BoardVO> selectlist() {
		return session.selectList("board.selectlist");
	}

	@Override
	public BoardVO selectone(int num) {
		// TODO Auto-generated method stub
		return session.selectOne("board.selectone", num);
	}

}
