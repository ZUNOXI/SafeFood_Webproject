package edu.ssafy.food.repository;

import java.util.List;

import edu.ssafy.food.dto.QnaVO;

public interface QnaRepo {
	public boolean insert(QnaVO q);
	public void update(QnaVO q);
	public boolean delete(int num);
	public List<QnaVO> selectlist();
	public QnaVO selectone(int num);
	public QnaVO selectpw(String pw);
	
}
