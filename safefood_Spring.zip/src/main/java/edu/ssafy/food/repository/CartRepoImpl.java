package edu.ssafy.food.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.ssafy.food.dto.CartVO;

@Repository("CartRepoImpl")
public class CartRepoImpl implements CartRepo {
	@Autowired
	private SqlSession session;

	@Override
	public void insert(CartVO c) {
		// TODO Auto-generated method stub
		session.insert("cart.insertcart", c);
	}

	@Override
	public List<Integer> selectlist(String id) {
		// TODO Auto-generated method stub
		return session.selectList("cart.selectcart", id);
	}

	@Override
	public void delete(int cartid) {
		// TODO Auto-generated method stub
		session.delete("cart.deletecart", cartid);
	}

	@Override
	public void update(CartVO c) {
		// TODO Auto-generated method stub
		session.update("cart.updatecart", c);
	}

	@Override
	public List<CartVO> selectAllList() {
		// TODO Auto-generated method stub
		return session.selectList("cart.selectlist");
	}

	@Override
	public List<CartVO> selectcartid(String id) {
		// TODO Auto-generated method stub
		return session.selectList("cart.selectcartid", id);
	}
	
	
}
