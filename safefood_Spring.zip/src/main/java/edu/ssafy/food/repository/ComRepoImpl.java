package edu.ssafy.food.repository;

import java.util.List;


import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.ssafy.food.dto.ComVO;

@Repository("ComRepoImpl")
public class ComRepoImpl implements ComRepo{
	
	@Autowired
	private SqlSession session;
	
	@Override
	public boolean insert(ComVO c) {
		// TODO Auto-generated method stub
		int res = session.insert("com.insert", c);
		if (res == 1)
			return true;
		else
			return false;
	}

	@Override
	public void update(ComVO c) {
		session.update("com.update", c);
	}

	@Override
	public boolean delete(int numc) {
		// TODO Auto-generated method stub
		int res = session.delete("com.delete", numc);
		if (res == 1)
			return true;
		else
			return false;
	}

	@Override
	public ComVO selectone(int numc) {
		return session.selectOne("com.selectone",numc);
	}

	@Override
	public List<ComVO> selectlist(int num) {
		// TODO Auto-generated method stub
		return session.selectList("com.selectlist",num);
	}

}
