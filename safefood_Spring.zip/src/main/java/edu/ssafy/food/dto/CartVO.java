package edu.ssafy.food.dto;

public class CartVO {

	private int cartid;
	private String userid;
	private int foodid;
	private int amount;
	
	
	public CartVO() {
	}

	

	public CartVO(String userid, int foodid, int amount) {
		super();
		this.userid = userid;
		this.foodid = foodid;
		this.amount = amount;
	}



	public CartVO(int cartid, String userid, int foodid, int amount) {
		this.cartid = cartid;
		this.userid = userid;
		this.foodid = foodid;
		this.amount = amount;
	}


	public int getCartid() {
		return cartid;
	}


	public void setCartid(int cartid) {
		this.cartid = cartid;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public int getFoodid() {
		return foodid;
	}


	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return "CartVO [cartid=" + cartid + ", userid=" + userid + ", foodid=" + foodid + ", amount=" + amount + "]";
	}
	
	
	

}
