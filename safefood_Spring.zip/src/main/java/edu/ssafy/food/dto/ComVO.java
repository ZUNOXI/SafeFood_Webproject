package edu.ssafy.food.dto;

public class ComVO {
	private int numc;
	private String content;
	private String id;
	private String pw;
	private int link;
	
	public ComVO() {
		
	}

	public ComVO(int numc, String content, String id, String pw, int link) {
		super();
		this.numc = numc;
		this.content = content;
		this.id = id;
		this.pw = pw;
		this.link = link;
	}

	public int getNumc() {
		return numc;
	}

	public void setNumc(int numc) {
		this.numc = numc;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public int getLink() {
		return link;
	}

	public void setLink(int link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return "ComVO [numc=" + numc + ", content=" + content + ", id=" + id + ", pw=" + pw + ", link=" + link + "]";
	}
	
}
