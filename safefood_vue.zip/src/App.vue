<template>
<div id="app">
<html lang='en'>
<head>
    <!-- css 매핑 -->
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="Free-Template.co" />

<link rel="shortcut icon" href="ftco-32x32.png">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

<link rel="stylesheet" href="/css/bootstrap.css">
<link rel="stylesheet" href="/css/animate.css">
<link rel="stylesheet" href="/css/owl.carousel.min.css">
<link rel="stylesheet" href="/css/aos.css">

<link rel="stylesheet" href="/css/magnific-popup.css">


<link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
<link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
<link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
<link rel="stylesheet" href="/css/style.css">
<link rel="stylesheet" href="/table.css">

<title>SafeFood</title>
</head>
    <body>
       
        <div>
            <br>
        <router-view/>
        </div>
       
        
    </body>
    
</html>
    
</div>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>

</style>
