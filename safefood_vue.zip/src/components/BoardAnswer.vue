<template>
  <html>
    <head>
      <link rel="shortcut icon" href="ftco-32x32.png">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

      <link rel="stylesheet" href="/css/bootstrap.css">
      <link rel="stylesheet" href="/css/animate.css">
      <link rel="stylesheet" href="/css/owl.carousel.min.css">
      <link rel="stylesheet" href="/css/aos.css">

      <link rel="stylesheet" href="/css/magnific-popup.css">


      <link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
      <link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
      <link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
      <link rel="stylesheet" href="/css/style.css">
      <link rel="stylesheet" href="/table.css">
    </head>
    <body>
  <div>
    <div class="col-md-12 text-center heading-wrap">
      <h2 >Notice</h2>
    </div>
    <br><br>
    <div id="aaa">
      <table class="qna_table">
        <col width="10%" />
        <col width="65%" />
        <col width="20%" />
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>글쓴이</th>
          <th>삭제</th>
        </tr>
        <tr v-for="board in info" class="nicecolor" :key="board.num">
          <td v-html="board.num" @click="show_detail(board.num)" style="cursor:pointer"></td>
          <td v-html="board.title" @click="show_detail(board.num)" style="cursor:pointer"></td>
          <td v-html="board.id"></td>
          <td class="button" @click="delete_emp(board.num)">
            <input type="button" class="blue" value="삭제"  style="cursor:pointer"/>
          </td>
        </tr>
      </table>
    </div>
    <div>
  </div>  
  <div class='search_box'>
  <nav>
        <router-link to="/addboard"><button class="snip1535">공지사항 추가하기</button></router-link>
  </nav>
  </div>
        <router-view/>
  </div>
    </body>
  </html>
</template>

<script>

import http from "../http-common";
export default {
  name: "Board",
  data() {
    return {
      upHere: false,
      info: [],
      loading: true,
      errored: false
    };
  },
  methods: {
    retrieveBoard() {
      http
        .get("/findAllBoard")
        .then(response => (this.info = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    refreshList() {
      this.retrieveBoard();
    },
    show_detail: function(bnum) {
      this.$router.push("/detailboard/" + bnum);
    },
    delete_emp(bnum) {
      alert("게시판번호"+ bnum + "번이 삭제됩니다.");
      http
        .post("/deleteBoard/" + bnum)
        .then(response => {
          if (response.data.state == "succ") {
            alert("삭제처리를 하였습니다.");
            this.retrieveBoard();
          } else {
            alert("삭제처리를 하였습니다.");
             this.retrieveBoard();
          }
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    }
  },
  mounted() {
    this.retrieveBoard();
  }
};
</script>

<style>
#aaa{
  text-align: center;
}
</style>
