<template>
<html>
  <head>
    <link rel="shortcut icon" href="ftco-32x32.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/aos.css">

    <link rel="stylesheet" href="/css/magnific-popup.css">


    <link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/table.css">
  </head>
  <body>
  <div>
    <div class="col-md-12 text-center heading-wrap">
      <h2 >Question & Answer</h2>
    </div>
    <br><br>

    <div v-if="!submitted">
      <form action method="post" id="_frmForm" name="frmForm" @submit.prevent="updateBoard">
        <table class="list_table">
          <colgroup>
            <col style="width:30%;" />
            <col style="width:70%;" />
          </colgroup>
          <tr>
            <th>제목</th>
            <td>
              <input
                data-msg="제목"
                type="text"
                name="ctitle"
                id="_ctitle"
                v-model="customer.title"
                style="width:50%"
              />
            </td>
          </tr>
          <tr>
            <th>작성자</th>
            <td>
              <input
                data-msg="작성자"
                type="text"
                name="cid"
                id="_cid"
                size="20"
                v-model="customer.id"
                style="width:50%"
              />
            </td>
          </tr>
          <tr>
            <th>내용</th>
            <td>
              <input
                data-msg="내용"
                type="text"
                name="ccontent"
                id="_ccontent"
                size="30"
                v-model="customer.content"
                style="width:50%; height:300px"
              />
            </td>
          </tr>
          <tr>
            <th>비밀번호</th>
            <td>
              <input
                data-msg="비밀번호"
                type="password"
                name="cpw"
                id="_cpw"
                size="30"
                v-model="customer.cpw"
                style="width:50%"
              />
            </td>
          </tr>
          <tr>
            <td colspan="2" style="height:50px; text-align:center;">
              <button type="submit" name="button" class="snip1535">정보수정하기</button>
            </td>
          </tr>
        </table>
      </form>
    </div>

    <div class="search_box" v-else>
      <h3>
        <button class="snip1535" @click="back_comment()">게시판으로 돌아가기</button>
      </h3>
    </div>
  </div>
  </body>
</html>
</template>

<script>
import http from "../http-common";

export default {
  name: "updateboard",
  props: ["num"],
  data() {
    return {
      info: null,
      loading: true,
      errored: false,
      deps: null,
      titls: null,
      customer: {
        cpw:""
      },
      submitted: false
    };
  },
  mounted() {
    http
      .get("/findQnaByNum/" + this.num)
      .then(response => {
        this.customer = response.data;
      })
      .catch(() => {
        this.errored = true;
      })
      .finally(() => (this.loading = false));
  },
  methods: {
    back_comment: function() {
     this.$router.push("/goQna");
   },
    updateBoard() {
      if (this.customer.ctitle == "") {
        alert("제목을 입력하세요.");
        return;
      }
      if (this.customer.cid == "") {
        alert("작성자를 입력하세요.");
        return;
      }
      if (this.customer.ccontent == "") {
        alert("내용을 입력하세요.");
        return;
      }
      if (this.customer.cpw == "") {
        alert("내용을 입력하세요.");
        return;
      }

      http
        .post("/updateQna", {
          num : this.num,
          title: this.customer.title,
          id: this.customer.id,
          content: this.customer.content,
          pw:this.customer.cpw
        })
        .then(response => {
          if (response.data == "succ") {
              alert("게시판번호" + this.num + "번이 수정됩니다.");
              alert("수정처리를 하였습니다.");
              this.back_comment();
          } else {
              alert("비밀번호가 일치하지 않습니다.");
              this.back_comment();
          }
        });
      this.submitted = true;
    },
    newCustomer() {
      (this.submitted = false),
        (this.info = null),
        (this.loading = true),
        (this.errored = false),
        (this.deps = null),
        (this.titls = null),
        (this.customer = {
          num: 0,
          ctitle: "",
          cid: "",
          ccontent: ""
        });
    }
  }
};
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
