<template>
  <html>
    <head>
      <link rel="shortcut icon" href="ftco-32x32.png">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

      <link rel="stylesheet" href="/css/bootstrap.css">
      <link rel="stylesheet" href="/css/animate.css">
      <link rel="stylesheet" href="/css/owl.carousel.min.css">
      <link rel="stylesheet" href="/css/aos.css">

      <link rel="stylesheet" href="/css/magnific-popup.css">


      <link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
      <link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
      <link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
      <link rel="stylesheet" href="/css/style.css">
      <link rel="stylesheet" href="/table.css">
    </head>
    <body>
  <div>
    <div>
      <div class="col-md-12 text-center heading-wrap">
      <h2 >Question & Answer</h2>
    </div>
      <br><br>
      <table class="qna_table">
        <col width="10%" />
        <col width="65%" />
        <col width="20%" />
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>글쓴이</th>
          <th>삭제</th>
        </tr>
        <tr v-for="qna in info" class="nicecolor" :key="qna.num">
          <td v-html="qna.num" @click="show_detail(qna.num)" style="cursor:pointer"></td>
          <td v-html="qna.title" @click="show_detail(qna.num)" style="cursor:pointer"></td>
          <td v-html="qna.id"></td>
          <td class="button" @click="delete_emp(qna.num)">
            <input type="button" class="blue" value="삭제" style="cursor:pointer"/>
          </td>
        </tr>
      </table>
    </div>
    <div>
  </div>  
  <div class='search_box'>
  <nav>
        <router-link to="/add"><button class="snip1535">게시글 추가하기</button></router-link>
  </nav>
  </div>
        <router-view/>
  </div>
    </body>
  </html>
</template>

<script>

import http from "../http-common";
export default {
  name: "Qnaboard",
  data() {
    return {
      upHere: false,
      info: [],
      loading: true,
      errored: false
    };
  },
  methods: {
    retrieveBoard() {
      http
        .get("/findAllQna")
        .then(response => (this.info = response.data))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    refreshList() {
      this.retrieveBoard();
    },
    show_detail: function(qnanum) {
      this.$router.push("/detailqna/" + qnanum);
    },
    delete_emp:function(qnanum) {
      this.$router.push("/deleteqna/"+qnanum);
    }
  },
  mounted() {
    this.retrieveBoard();
  }
};
</script>

<style>
</style>
