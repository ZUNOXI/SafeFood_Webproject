<template>
<html>
	<head>
		<link rel="shortcut icon" href="ftco-32x32.png">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

		<link rel="stylesheet" href="/css/bootstrap.css">
		<link rel="stylesheet" href="/css/animate.css">
		<link rel="stylesheet" href="/css/owl.carousel.min.css">
		<link rel="stylesheet" href="/css/aos.css">

		<link rel="stylesheet" href="/css/magnific-popup.css">


		<link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
		<link rel="stylesheet" href="/css/style.css">
		<link rel="stylesheet" href="/table.css">
	</head>
	<body>
	<div class="col-md-12 text-center heading-wrap">
      <h2 >Notice</h2>
    </div>
    <br><br>
	<div id="aaa"> 
		<div v-if="!submitted">
			<form action="" method="post" id="_frmForm" name="frmForm" @submit.prevent="addEmployee">
				<table class="list_table">
					<colgroup>
						<col style="width:30%;" />
						<col style="width:auto;" />
					</colgroup>
					<tr>
						<th>제목</th>
						<td><input data-msg="제목" type="text" name="title" id="_title" v-model="ctitle"
								style="width:80%"/></td>
					</tr>
					<tr>
						<th>작성자</th>
						<td><input data-msg="작성자" type="text" name="id" id="_id" size="20" v-model="cid"
							style="width:80%"	/></td>
					</tr>
					<tr>
						<th>내용</th>
						<td><textarea data-msg="내용" name="content" id="_content" size="600" v-model="ccontent"
								style="width:80%; height:300px" /></td>
</tr>
<tr>
<td colspan="2" style="height:50px; text-align:center;">
<button type="submit" name="button" class="snip1535">게시글 추가</button></td>
</tr>
</table>
</form>
</div>

<div v-else>
	<p style="color:orange;">성공적으로 게시글을 추가하였습니다!</p>
	<button class="snip1535" @click="back_comment()">게시판으로 돌아가기</button>
    </div>
</div>
	</body>
</html>
</template>

<script>
import http from "../http-common";

export default {
	name: "add-board",
	data() {
		return {
			info: null,
			loading: true,
			errored: false,
			ctitle:'',
			cid:'',
			ccontent:'',
			submitted: false
		};
	},
	mounted () {
	http
		.get('/findAllBoard')
		.then(response => (this.info = response.data))
		.catch(() => {
			this.errored = true
		})
		.finally(() => this.loading = false);
	},
	methods: {
		back_comment: function() {
		this.$router.push("/goBoard");
		},
		addEmployee() {
		if(this.ctitle==''){ alert('제목을 입력하세요.'); return ;}
		if(this.cid==''){ alert('작성자를 입력하세요.'); return ;}
		if(this.ccontent==''){ alert('내용을 입력하세요.'); return ;}
		
		http.post('/addBoard', {
			num:0,
			title: this.ctitle,
			content: this.ccontent,
			id:this.cid
		} 
		).then(response => {
				if (response.data.state=='succ') {
					alert("게시글을 입력하였습니다.");
				}else{
					alert("게시글을 입력하였습니다.");
				}
		});
		this.submitted = true;
	},
	newCustomer() {
		this.submitted=false,
		this.info=null,
		this.loading=true,
		this.errored=false,
		this.deps=null,
		this.titls=null,
		this.ccommission_pct=0,
		this.cdept_id=0,
		this.cmailid='',
		this.cmanager_id=0,
		this.cname='',
		this.csalary=0,
		this.cstart_date='',
		this.ctitle=''
	}
  }
}
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}

#aaa{
	text-align: center;
}
td{
	width:auto;

}
</style>