<template>
    <div style="margin-left: 200px">
        <table id="content" style="width: 90%; margin: 0 auto">

            <c:forEach var="product" items="${foodlist }">
                <tr style='margin-left:200px'>
                    <td>
                        <a href='pdetail/code/{{product.code}}'>
                            <img width='180px' src="{{product.image}}"
                                class='btn btn-gray-transparent btn-animated btn-sm'></a>
                        상품 정보로 이동 <i class='pl-10 fa fa-arrow-right'></i>
                        <p style='font-size:18px; opacity:0.7 '>{{product.name }}</p>
                        <c:set var="alcheck" value="${product.material }"></c:set>
                        <c:forEach var="a" items="${alinfo }">
                            <c:if test="${fn:contains(alcheck, a)}">
                                <h4 style="color:red">{{a}} 알러지가 포함되어 있는 상품입니다!!!!</h4>
                            </c:if>
                        </c:forEach>
                        <br>
                        <span class='glyphicon glyphicon-calendar'> Feb, 2017 </span>&emsp;
                        <span class='glyphicon glyphicon-tag'>Web Design</span><br />
                        <hr>
                        <p style='opacity:0.6'>{{product.material }}</p>
                        <button class='btn btn-sm btn-info' type='button'>
                            <img width='20px' src='./img/사람.png'>추가</button>
                        <button class='btn btn-sm btn-info' type='button'>
                            <img width='20px' src='./img/사람.png'>찜 </button>
                    </td>

                </tr>

            </c:forEach>

        </table>9
    </div>
</template>