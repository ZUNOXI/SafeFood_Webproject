<template>
    <html>

    <head>
        <link rel="shortcut icon" href="ftco-32x32.png">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">
        <link rel="stylesheet" href="/css/bootstrap.css">
        <link rel="stylesheet" href="/css/animate.css">
        <link rel="stylesheet" href="/css/owl.carousel.min.css">
        <link rel="stylesheet" href="/css/aos.css">
        <link rel="stylesheet" href="/css/magnific-popup.css">
        <link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
        <link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/table.css">
    </head>

    <body>
        <div>
            <div v-if="!submitted">
                <form action="" method="post" id="_frmForm" name="frmForm" @submit.prevent="addEmployee">
                    <table class="list_table">
                        <colgroup>
                            <col style="width:30%;" />
                            <col style="width:70%;" />
                        </colgroup>
                        <tr>
                            <td>비밀번호를 입력하세요</td>
                        </tr>
                        <tr>
                            <th>비밀번호</th>
                            <td><input data-msg="비밀번호" type="password" name="pw" id="_pw"
                             v-model="cpw" style="width:50%" /></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="height:50px; text-align:center;">
                                <input type="button" name="button" class="snip1535" @click="delete_emp()" value="삭제하기"></td>
                        </tr>
                    </table>
                </form>
            </div>

            <div v-else>
                <button class="snip1535" @click="back_comment()">게시판으로 돌아가기</button>
            </div>
        </div>
    </body>

    </html>
</template>

<script>
    import http from "../http-common";

    export default {
        name: "add-qna",
        props: ["num"],
        data() {
            return {
                info: null,
                loading: true,  
                errored: false,
                cpw: '',
                submitted: false
            };
        },
        mounted() {
            http
                .post('/deleteQna/this.info')
                .then(response => (this.info = response.data))
                .catch(() => {
                    this.errored = true
                })
                .finally(() => this.loading = false);
        },
        methods: {
            back_comment: function () {
                this.$router.push("/goQna");
            },
            delete_emp: function () {
                http
                    .post("/deletecom/" + this.cpw +"/"+ this.num)
                    .then(response => {
                        if (response.data == "succ") {
                            alert("댓글이 삭제됩니다.");
                            alert("삭제처리를 하였습니다.");
                            this.back_comment();
                        } else {
                            alert("비밀번호가 일치하지 않습니다.");
                            this.back_comment();
                        }
                    })
                    .catch(() => {
                        this.errored = true;
                    })
                    .finally(() => (this.loading = false));
            },
            retrieveBoard() {
                http
                    .get("/findAllQna")
                    .then(response => (this.info = response.data))
                    .catch(() => {
                        this.errored = true;
                    })
                    .finally(() => (this.loading = false));
            }

        }
    }
</script>

<style>
    .submitform {
        max-width: 300px;
        margin: auto;
    }
</style>