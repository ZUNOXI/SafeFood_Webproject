<template>
<html>
  <head>
    <link rel="shortcut icon" href="ftco-32x32.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800" rel="stylesheet">

    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/aos.css">

    <link rel="stylesheet" href="/css/magnific-popup.css">


    <link rel="stylesheet" href="/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/table.css">

  </head>
  <body>
 <div>
   <div class="col-md-12 text-center heading-wrap">
      <h2 >Question & Answer</h2>
    </div>
    <br><br>
   <table class="list_table">
     <col width="10%" />
     <col width="20%" />
     <col width="20%" />
     <col width="20%" />
     <col width="10%" />
	<tr>
	<th>제목</th>
	<td v-html="cemp.title"></td>
	</tr>
	<tr>
	<th>작성자</th>
    <td v-html="cemp.id"></td>
	</tr>
	<tr>
	<th>내용</th>
    <td v-html="cemp.content"></td>
	</tr>
   </table>
   <div class='search_box'>
  <nav>
        <button class="snip1535" @click="show_detail(cemp.num)">게시글 수정하기</button>
        <button class="snip1535" @click="make_comment(cemp.num)">댓글 작성하기</button>
  </nav>
  </div>
   <br>
   <h1 style="text-align:center;"><img src="/img/chat.png" style="width:40px"> COMMENT</h1>
    <br>
   <table class="list_table2">
     <col width="92%" />
     <col width="8%" />
     <tr v-for="com in ccoment" :key="com.numc">
      <td>
      <img src="/img/comment.png" style="width:20px">
      <span> / </span>
      <span v-html="com.id"></span>
      <span> : </span>
      <span v-html="com.content"></span>
      </td> 
      <td class="button" @click="delete_emp(com.numc)">
            <input type="button" value="삭제" style="cursor:pointer"/>
      </td>
     </tr>
   </table>
 </div> 
  </body>
</html>
</template>
<script>
import http from "../http-common";
export default {
 name: "detailcustomer",
 props: ["num"],
 data() {
   return {
     info: [],
     loading: true,
     errored: false,
     cemp: {},
     ccoment:[]
   };
 },
 filters: {
   salarydecimal(value) {
     var a = parseInt(value);
     return a.toFixed(2);
   }
 },
 methods: {
   back_comment: function() {
		this.$router.push("/goQna");
		},
   show_detail: function(num) {
     alert(num + "수정하기");
     this.$router.push("/updateQna/" + num);
   },
   make_comment: function(num) {
     alert("댓글 작성하기");
     this.$router.push("/Addcomment/" + num);
   },
   show_init: function() {
     http
       .get("/findQnaByNum/" + this.num)
       .then(response => (this.cemp = response.data))
       .catch(() => {
         this.errored = true;
       })
       .finally(() => (this.loading = false));
   },
   show_init2: function() {
     http
       .get("/findAllComment/" + this.num)
       .then(response => (this.ccoment = response.data))
       .catch(() => {
         this.errored = true;
       })
       .finally(() => (this.loading = false));
   },
    delete_emp:function(num) {
      this.$router.push("/deletecom/"+num);
    }
 },
 mounted() {
   this.show_init();
   this.show_init2();
 }
};
</script>
<style>
.searchform {
 max-width: 300px;
 margin: auto;
}
.search-result {
 margin-top: 20px;
 text-align: left;
}
</style>