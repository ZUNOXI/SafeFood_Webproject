import Vue from "vue";
import Router from "vue-router";
// import MainTest1 from "./components/HelloWorld.vue";
import QeustionAnswer from "./components/QeustionAnswer.vue";
import Addqna from "./components/Addqna.vue";
import Detailboard from "./components/DetailBoard.vue";
import Updateqna from "./components/Updateqna.vue";
import BoardAnswer from "./components/BoardAnswer.vue";
import Updateboard from "./components/Updateboard.vue";
import Addboard from "./components/Addboard.vue";
import Addcomment from "./components/Addcomment.vue"
import DetailQna from "./components/Detailqna.vue";
import DeleteQna from "./components/DeleteQna.vue";
import DeleteCom from "./components/DeleteComment.vue";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    // {
    //   path: "/",
    //   name: "MainTest",
    //   alias: "/maintest",
    //   component: MainTest1
    // },
    {
      path: "/goBoard",
      name: "BoardAnswer",
      component: BoardAnswer
    },
    {
      path: "/goQna",
      name: "QeustionAnswer",
      component: QeustionAnswer
    },
    {
      path: "/add",
      name: "Addqna",
      component: Addqna
    },
    {
      path: "/detailqna/:num",
      name: "detailqna",
      component: DetailQna,
      props: true,
    } ,
    {
      path: "/deleteqna/:num",
      name: "deleteqna",
      component: DeleteQna,
      props: true,
    } ,
    {
      path: '/updateQna/:num',
      name: 'updateqna',
      component: Updateqna,
      props: true,
    },
    {
      path: "/detailboard/:num",
      name: "detailBoard",
      component: Detailboard,
      props: true,
    },
    {
      path: '/updateBoard/:num',
      name: 'updateboard',
      component: Updateboard,
      props: true,
    },
    {
      path: "/addBoard",
      name: "Addboard",
      component: Addboard
    },
    {
      path: '/Addcomment/:num',
      name: 'Addcomment',
      component: Addcomment,
      props: true,
    },{
      path: "/deletecom/:num",
      name: "deletecom",
      component: DeleteCom,
      props: true,
    } 
  ]
});